class ToolsOutput_Class:
    def PrintStringOnSeperateLine(StringToPrint):
        print(StringToPrint)