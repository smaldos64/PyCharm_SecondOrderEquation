class Point_Class:
    def __init__(self, x_value = 0, y_value = 0):
        self.x_value = x_value
        self.y_value = y_value